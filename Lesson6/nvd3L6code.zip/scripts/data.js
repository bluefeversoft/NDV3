var chartData = [];

var getValues = function() {
  var labs = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  var ourData = [];

  for (var i = 0; i < labs.length; ++i) {
    ourData.push({
      label: labs[i],
      value: Math.floor(Math.random() * 100) - 50
    })
  }

  console.log('ourData:',ourData);
  return ourData;
}

var refreshChartData = function() {
  chartData = [
    {
      key: "Cumulative Return",
      values: getValues()
    }
  ];
}












































