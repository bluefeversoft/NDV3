var getColorArray = function(data) {
	col_array = [];

	for (var i = 0; i < data.length; i++) {
		col = '#D50000';
		if(data[i].value >= 0) {
			col = '#1B5E20';
		}
		col_array.push(col);
	}
	return col_array;
}

var clearChart = function() {
	svg = d3.select('#chart svg');
	svg.selectAll("*").remove();
}

var forceYAxis = function() {

  minY = $("#inMinY").val();
  maxY = $("#inMaxY").val();

  console.log('minY:' , minY);
  console.log('maxY:' , maxY);

  if(minY != '') {
	drawChart( [ parseInt(minY), parseInt(maxY)] );
  } else {
  	drawChart();
  }

}

var drawChart = function(forceYargs) {

		nv.addGraph(function() {
	  var chart = nv.models.discreteBarChart()
	    .x(function(d) { return d.label })
	    .y(function(d) { return d.value })
	    .staggerLabels(false)
	    .showValues(true)
	    .color(getColorArray(chartData[0]['values']))

	    chart.tooltip.enabled(true);

	    if(forceYargs) {
	      console.log('forcing Y',forceYargs);
	      chart.forceY(forceYargs);
	    }

	  d3.select('#chart svg')
	    .datum(chartData)
	    .transition().duration(500)
	    .call(chart)
	    ;

	  nv.utils.windowResize(chart.update);

	  return chart;
	});

};

$(function() {

	refreshChartData();

	$("#btnLoadChart").click(function(){
		console.log('draw chart');
		drawChart();
	});

	$("#btnClearChart").click(function(){
		console.log('clear chart');
		clearChart();
	});

	$("#btnRefreshData").click(function(){
		console.log('refreshChartData');
		refreshChartData();
		drawChart();
	});

	$("#btnForceY").click(function(){
		console.log('btnForceY');
		forceYAxis();
	});
});













