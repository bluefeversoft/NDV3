var chartData = [
  {
    key: "Cumulative Return",
    values: [
      { 
        "label" : "A" ,
        "value" : -29.765957771107
      } , 
      { 
        "label" : "B" , 
        "value" : 5
      } , 
      { 
        "label" : "C" , 
        "value" : 32.807804682612
      } 
    ]
  }
];
