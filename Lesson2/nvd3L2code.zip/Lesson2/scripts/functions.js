
var drawChart = function() {

		nv.addGraph(function() {
	  var chart = nv.models.discreteBarChart()
	    .x(function(d) { 
	    	console.log('d:' , d);
	    	return d.label 
	    })
	    .y(function(d) { return d.value })
	    .staggerLabels(false)
	    .showValues(false)

	    chart.tooltip.enabled(true);

	  d3.select('#chart svg')
	    .datum(chartData)
	    .transition().duration(500)
	    .call(chart)
	    ;

	  nv.utils.windowResize(chart.update);

	  return chart;
	});

};

$(function() {
	$("#btnLoadChart").click(function(){
		console.log('draw chart');
		drawChart();
	});
});