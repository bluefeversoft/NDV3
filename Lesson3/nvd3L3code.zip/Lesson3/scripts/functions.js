var getColorArray = function(data) {
	col_array = [];

	for (var i = 0; i < data.length; i++) {
		col = '#D50000';
		if(data[i].value >= 0) {
			col = '#1B5E20';
		}
		col_array.push(col);
	}

	console.log(col_array);
	return col_array;
}


var drawChart = function() {

		nv.addGraph(function() {
	  var chart = nv.models.discreteBarChart()
	    .x(function(d) { return d.label })
	    .y(function(d) { return d.value })
	    .staggerLabels(false)
	    .showValues(true)
	    .color(getColorArray(chartData[0]['values']))

	    chart.tooltip.enabled(true);

	  d3.select('#chart svg')
	    .datum(chartData)
	    .transition().duration(500)
	    .call(chart)
	    ;

	  nv.utils.windowResize(chart.update);

	  return chart;
	});

};

$(function() {
	$("#btnLoadChart").click(function(){
		console.log('draw chart');
		drawChart();
	});
});